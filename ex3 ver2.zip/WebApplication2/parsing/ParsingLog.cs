﻿using WebApplication2.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WebApplication2.parsing
{
    class ParsingLog
    {

        /**
         *  The function accepts a string, separates it into words, according to the convention(#), 
         *  and create ObservableCollection of LogProperties
         *  @ param message - string of logs history. 
         **/
        public List<LogProperties> parsingLogs(string message)
        {
            List<LogProperties> logs = new List<LogProperties>();
            string[] msg = message.Split('#');
            for (int i = 1; i < msg.Length && i + 1 < msg.Length; i += 2)
            {
                LogProperties newlog = new LogProperties(msg[i], msg[i + 1]);
                logs.Add(newlog);
            }
            return logs;
        }

        /**
         *  The function accepts a string, separates it into words, according to the convention(#), 
         *  and create LogProperties
         *  @ param message - string of log. 
         **/
        public LogProperties parsingLog(string message)
        {
            string[] msg = message.Split('#');
            return new LogProperties(msg[1], msg[2]); 
        }
    }
}
