﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using WebApplication2.Communication;
using System.Linq;
using System.Web;
using System.IO;
using System.Web.Hosting;

namespace WebApplication2.Models
{
    public class ImageWebModel
    {
        public List<student> Students { get; set; }
        public ImageWebModel()
        {
            getStatusService();
            getStudentDetails();
            getNumOfPic();
        }

        /**
         * the function tries to connect to the service, 
         * if it succeed the status will be  runing.
         * else the status will be stop.
         * */
        private void getStatusService()
        {
            try
            {
                Client client = Client.Instance;
                // if the connection is successful, the background color will be white.
                Status = "The service running";
            }
            catch (Exception e)
            {
                Status = "The service stop";
            }
        }

        /**
        * the function opened the details file, and read the students details into the matching values. 
        * */
        private void getStudentDetails()
        {
            
            using (StreamReader sr = new StreamReader(HostingEnvironment.MapPath("~/" + "/App_Data/details.txt")))
            {
                string[] text = sr.ReadLine().Split(' ');
                Students = new List<student>()
                {
                    new student  {ID = text[2], FirstName = text[1], LastName = text[0]},
                    new student  {ID = text[5], FirstName = text[4], LastName = text[3]},
                };
            }
        }

        /**
         * the function opens the output directory and counts how many photos are in the directory.
         **/
        private void getNumOfPic()
        {
            string s = HostingEnvironment.MapPath("~/" + "/resource/output");
            int num = Directory.GetFiles(s, "*", SearchOption.AllDirectories).Length;
            // I divided in 2 because I count the thumbnail image and the image.
            NumOfPic = (num/2).ToString();
        }

        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "Status")]
        public string Status { get; set; }

        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "NumOfPic")]
        public string NumOfPic { get; set; }

        
    }
}