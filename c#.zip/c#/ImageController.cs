﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ImageService.Logging.Modal;

namespace ImageService
{
    class ImageController : IImageController
    {
        private IImageServiceModal imageModal;                     
        private Dictionary<int, ICommand> commands;

        /**
         * @arg modal - IImageServiceModal object that we created in "Imageservice".
         * Storing the Modal Of The System, and create dictionary for commands,
         * and add the commands.  
         **/
        public ImageController(IImageServiceModal modal) {
            imageModal = modal;                                     
            // set commands dictionary.
            commands = new Dictionary<int, ICommand>();
            ICommand newFile = new NewFileCommand(imageModal);
            commands.Add(0, newFile);
        }

        /**
         * @arg commandID - The key of a specific command.
         * @arg args - array that contain the args to command.
         * @arg resultSuccesful (Success or failure).
         * Finds the desired task using the key, and calls its execution method.
         **/
        public string ExecuteCommand(int commandID, string[] args, out bool resultSuccesful) {
               return commands[commandID].Execute(args, out resultSuccesful);
        }
    }
}

      