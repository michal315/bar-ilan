﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using ImageService.Logging;
using ImageService.Logging.Modal;
using System.Text.RegularExpressions;
using System.Security.Permissions;


namespace ImageService
{
     public class DirectoryHandler : IDirectoryHandler
    {
        private IImageController controller;              // The Image Processing Controller
        private ILoggingService logging;
        private FileSystemWatcher dirWatcher;             // The Watcher of the Dir
        private string path;                              // The Path of directory
        // The Event That Notifies that the Directory is being closed
        public event EventHandler<DirectoryCloseEventArgs> DirectoryClose;

        /**
        * @arg path - 
        * 
        * Storing the Modal Of The System, and create dictionary for commands,
        * and add the commands.  
        **/
        public DirectoryHandler(string path, IImageController controller, ILoggingService logging) {
            this.path = path;
            this.logging = logging;
            this.controller = controller;
            this.dirWatcher = new FileSystemWatcher();
            dirWatcher.Path = path;
            dirWatcher.EnableRaisingEvents = true;
            dirWatcher.Created += new FileSystemEventHandler(OnCreated);
        }

        private void OnCreated(object source, FileSystemEventArgs e) {
            string file = e.Name;
            // filter file types 
            if (file.EndsWith(".jpg") || file.EndsWith(".bmp") || file.EndsWith(".gif") || file.EndsWith(".png")) { 
                string[] args = new string[2];
                args[0] = e.FullPath;
                args[1] = e.Name;
                bool result;
                string message = controller.ExecuteCommand(0, args, out result);
                if (result)
                {
                    this.logging.Log(message, MessageTypeEnum.INFO);
                }
                else
                {
                    this.logging.Log(message, MessageTypeEnum.FAIL);
                }
            } 
        }

        private void OnClosed(object source, FileSystemEventArgs e) {
            DirectoryCloseEventArgs dirClose = new DirectoryCloseEventArgs(this.path, "close");
            DirectoryClose.Invoke(this, dirClose);
        }


        public void OnCommandRecieved(object sender, CommandRecievedEventArgs e) {
            if (e.CommandID == 0) {
                try {
                    dirWatcher.EnableRaisingEvents = false;
                    this.logging.Log(path + " closed", MessageTypeEnum.INFO);
                }
                catch (Exception ex) {
                    this.logging.Log(ex.Message, MessageTypeEnum.FAIL);
                }
            }
        }

        public void StartHandleDirectory(string dirPath) {

        }
    }
}
