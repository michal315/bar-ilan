﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ImageServiceGui.model;
using ImageServiceGui.Communication.client;
using ImageServiceGui.viewModel;
using System.ComponentModel;

namespace ImageServiceGui.view
{
    /// <summary>
    /// Interaction logic for Settings.xaml
    /// </summary>
    public partial class Settings : UserControl
    {
        public Settings() {
            InitializeComponent();
            SettingsModel sm = new SettingsModel();
            SettingsViewModel settingsVM = new SettingsViewModel(sm);
            settingsVM.MessageRecieved += sm.closeHandler;
            DataContext = settingsVM;
        }

    }
}
