﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Threading;
using ImageServiceGui.Communication.client;
using ImageServiceGui.parsing;
using System.Collections.ObjectModel;

namespace ImageServiceGui.model {
    class SettingsModel : INotifyPropertyChanged {

        public event PropertyChangedEventHandler PropertyChanged;
        private Client client;
        private ParsingConfig parse;
        private string m_outputDirectory;
        private string m_sourceName;
        private string m_logName;
        private string m_thumbnailSize;
        private string m_connect;
        private ObservableCollection<string> m_handlers;


        public SettingsModel()
        {
            parse = new ParsingConfig(this);
            //client TCP
            try
            {
                client = Client.Instance;
                client.MessageRecieved += getMessage;
                // if the connection is successful, the background color will be white.
                connect = "White";
                
            } catch (Exception e)
            {
                // if the connection is  failed, the background color will be grey.
                connect = "Gray";
            }
            
            
        }
        public string outputDirectory {
            set {m_outputDirectory = value;
                NotifyPropertyChanged("outputDirectory");}
            get { return m_outputDirectory; }
        }

        public string connect
        {
            set
            {
                m_connect = value;
                NotifyPropertyChanged("connect");
            }
            get { return m_connect; }
        }

        public string sourceName {
            set {
                m_sourceName = value;
                NotifyPropertyChanged("sourceName");}
            get { return m_sourceName; }
        }
        public string logName {
            set {
                m_logName = value;
                NotifyPropertyChanged("logName");}
            get { return m_logName; }
        }
        public string thumbnailSize {
            set {
                m_thumbnailSize = value;
                NotifyPropertyChanged("thumbnailSize");
            }
            get { return m_thumbnailSize; }
        }
        public ObservableCollection<string> handlers {
            set {
                m_handlers = value;
                NotifyPropertyChanged("handlers");
            }
            get { return m_handlers; }
        }

        /**
         * When an closeDir event happens this function activate.
         * And writes to the server about it.
         **/
        public void closeHandler(Object sender, string handler) {
            client.write("closeDir#" + handler);
        }

        /**
         * When an new message event happens this function activate.
         * The function handles messages related to the logs window.
         **/
        public void getMessage(Object sender, string message) {
            Console.WriteLine("get massega settings model");
            string[] msg = message.Split('#');
            if (string.Equals(msg[0], "config")) {
                parse.parse(message);
            }
            if (string.Equals(msg[0], "closeDir"))
            {
                App.Current.Dispatcher.Invoke((Action)(() => handlers.Remove(msg[1])));
                NotifyPropertyChanged("handlers");
                Console.WriteLine(handlers.Count);
            }
        }

        /**
         * When Property is updated the function is enabledz.
         **/
        public void NotifyPropertyChanged(string propName) {
            if (this.PropertyChanged != null)
                this.PropertyChanged(this, new PropertyChangedEventArgs(propName));
        }

    }
}
