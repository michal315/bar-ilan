﻿using System;
using System.ComponentModel;
using System.Threading;
using ImageServiceGui.Communication.client;
using ImageServiceGui.parsing;
using System.Collections.ObjectModel;

namespace ImageServiceGui.model
{
    class LogModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private Client client;
        ObservableCollection<LogProperties> m_logs;
        ParsingLog parsLog;
        private string m_connect;

        public LogModel()
        {
            parsLog = new ParsingLog();
            m_logs = new ObservableCollection<LogProperties>();
            Object locker = new Object();
            System.Windows.Data.BindingOperations.EnableCollectionSynchronization(m_logs, locker);
            try
            {
                //client TCP
                client = Client.Instance;
                client.MessageRecieved += getMessage;
                Thread.Sleep(1000);
                // if the connection is successful, the background color will be white.
                connect = "White";
            } catch (Exception e)
            {
                // if the connection is  failed, the background color will be grey.
                connect = "Gray";
            }

}

        public ObservableCollection<LogProperties> logs
        {
            set
            {
                m_logs = value;
                NotifyPropertyChanged("logs");
            }
            get { return m_logs; }
        }

        public string connect
        {
            set
            {
                m_connect = value;
                NotifyPropertyChanged("connect");
            }
            get { return m_connect; }
        }

        /**
         * When an new message event happens this function activate.
         * The function handles messages related to the logs window.
         **/
        public void getMessage(Object sender, string message)
        {
            string[] msg = message.Split('#');
            // Single log received while running.
            if (string.Equals(msg[0], "log"))
            {
                // the parsing of the message to property.
                LogProperties lp = parsLog.parsingLog(message);
                App.Current.Dispatcher.Invoke((Action)(() => m_logs.Add(lp)));
                NotifyPropertyChanged("logs");
            }
            // The history of the logs, which is obtained at the moment of connection to the server.
            if (string.Equals(msg[0], "logs"))
            {
                m_logs = parsLog.parsingLogs(message);
            }
        }

        /**
         * When Property is updated the function is enabledz.
         **/
        public void NotifyPropertyChanged(string propName)
        {
            if (this.PropertyChanged != null)
                this.PropertyChanged(this, new PropertyChangedEventArgs(propName));
        }

    }
}
