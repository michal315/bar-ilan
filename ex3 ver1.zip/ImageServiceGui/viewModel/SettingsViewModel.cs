﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using ImageServiceGui.model;
using System.Windows.Input;
using System.Collections.ObjectModel;

namespace ImageServiceGui.viewModel
{
    class SettingsViewModel : INotifyPropertyChanged {
        public event PropertyChangedEventHandler PropertyChanged;
        public event EventHandler<string> MessageRecieved;
        private SettingsModel model;
        public string VM_dirToClose;
        public ICommand removeCommand {get;private set; }


        public SettingsViewModel(SettingsModel model) {
            dirToClose = null;
            this.model = model;
            this.removeCommand = new MyICommand(this.OnRemove, this.CanRemove);
            model.PropertyChanged += delegate(Object sender, PropertyChangedEventArgs e)
            {
                NotifyPropertyChanged("VM_" + e.PropertyName);
            };
        }

        private void OnRemove()
        {
            MessageRecieved.Invoke(this, dirToClose);
        }


        private bool CanRemove()
        {
            Console.WriteLine(dirToClose);
            if (string.IsNullOrEmpty(dirToClose))
            {
                return false;
            }
            return true;
        }
        
        public void NotifyPropertyChanged(string propName) {
            if (this.PropertyChanged != null)
                this.PropertyChanged(this, new PropertyChangedEventArgs(propName));
        }

        public string VM_connect
        {
            get { return model.connect; }
        }

        public string VM_outputDirectory {
            get { return model.outputDirectory; }
        }
        public string VM_sourceName {
            get { return model.sourceName; }
        }
        public string VM_logName {
            get { return model.logName; }
        }
        public string VM_thumbnailSize {
            get { return model.thumbnailSize; }
        }
        public ObservableCollection<string> VM_handlers {
            get { return model.handlers; }
        }

        public string dirToClose {
            set {
                VM_dirToClose = value;
            }
            get { return VM_dirToClose; }
        } 

    }
}
