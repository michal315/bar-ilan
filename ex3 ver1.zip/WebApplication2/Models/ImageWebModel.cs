﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using WebApplication2.Communication;
using System.Linq;
using System.Web;
using System.IO;
using System.Web.Hosting;

namespace WebApplication2.Models
{
    public class ImageWebModel
    {
        public List<student> Students { get; set; }
        public ImageWebModel()
        {
            getStatusService();
            getStudentDetails();
            getNumOfPic();
        }

        private void getStatusService()
        {
            try
            {
                Client client = Client.Instance;
                // if the connection is successful, the background color will be white.
                Status = "The service running";
            }
            catch (Exception e)
            {
                Status = "The service stop";
            }
        }

        private void getStudentDetails()
        {
            
            using (StreamReader sr = new StreamReader(HostingEnvironment.MapPath("~/" + "/App_Data/details.txt")))
            {
                string[] text = sr.ReadLine().Split(' ');
                Students = new List<student>()
                {
                    new student  {ID = text[2], FirstName = text[1], LastName = text[0]},
                    new student  {ID = text[5], FirstName = text[4], LastName = text[3]},
                };
            }
        }

        private void getNumOfPic()
        {
            string s = HostingEnvironment.MapPath("~/" + "/resource/output");
            int num = Directory.GetFiles(s, "*", SearchOption.AllDirectories).Length;
            NumOfPic = (num/2).ToString();
        }

        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "Status")]
        public string Status { get; set; }

        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "NumOfPic")]
        public string NumOfPic { get; set; }

        
    }
}