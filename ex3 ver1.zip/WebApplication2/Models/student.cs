﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Models
{
    public class student
    {
        public student()
        {
           
        }
        public void copy(student emp)
        {
            FirstName = emp.FirstName;
            LastName = emp.LastName;
            ID = emp.ID;
        }

        [Required]
        // בהנתן האימפלוי תציג את הערך ID
        [DataType(DataType.Text)]
        [Display(Name = "ID")]
        public string ID { get; set; }

        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "FirstName")]
        public string FirstName { get; set; }

        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "LastName")]
        public string LastName { get; set; }
    }
}