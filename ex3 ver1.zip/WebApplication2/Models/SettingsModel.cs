﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Threading;
using WebApplication2.Communication;
using WebApplication2.parsing;
using System.Collections.ObjectModel;
using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Models {
    public class SettingsModel : INotifyPropertyChanged {

        public event PropertyChangedEventHandler PropertyChanged;
        private Client client;
        private ParsingConfig parse;
        private string m_outputDirectory;
        private string m_sourceName;
        private string m_logName;
        private string m_thumbnailSize;
        private List<string> m_handlers = new List<string>();
        public event EventHandler<string> update;
        private bool deleteDir = false;

        public SettingsModel()
        {
            sourceName = "ffffff";
            outputDirectory = "gggggggg";
            handlers.Add("llllll");
            handlers.Add("ppppp");
            handlers.Add("buvutcrtcdrszez");
            //client TCP
            try
            {
                client = Client.Instance;
                client.MessageRecieved += getMessage;      
            } catch (Exception e)
            {
            }
            parse = new ParsingConfig(this);
        }

        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "outputDirectory")]
        public string outputDirectory {
            set {m_outputDirectory = value;
                }
            get { return m_outputDirectory; }
        }

        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "sourceName")]
        public string sourceName {
            set {
                m_sourceName = value;
                }
            get { return m_sourceName; }
        }

        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "logName")]
        public string logName {
            set {
                m_logName = value;}
            get { return m_logName; }
        }

        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "thumbnailSize")]
        public string thumbnailSize {
            set {
                m_thumbnailSize = value;
            }
            get { return m_thumbnailSize; }
        }
        public List<string> handlers {
            set {
                m_handlers = value;
            }
            get { return m_handlers; }
        }

        /**
         * When an closeDir event happens this function activate.
         * And writes to the server about it.
         **/
        public void closeHandler(Object sender, string handler) {
            client.write("closeDir#" + handler);
        }

        public void DeleteHandler(string handler)
        {
            client.write("closeDir#" + handler);
            while (deleteDir == false)
            {
                Thread.Sleep(200);
            }
            deleteDir = false;
        }
        /**
         * When an new message event happens this function activate.
         * The function handles messages related to the logs window.
         **/
        public void getMessage(Object sender, string message) {
            string[] msg = message.Split('#');
            if (string.Equals(msg[0], "config")) {
                parse.parse(message);
                update.Invoke(this, "update");
            }
            if (string.Equals(msg[0], "closeDir"))
            {
                handlers.Remove(msg[1]);
                deleteDir = true;
            }
        }

       

    }
}
