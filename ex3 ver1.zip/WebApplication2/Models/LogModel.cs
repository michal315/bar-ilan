﻿using System;
using System.Windows.Threading;
using System.ComponentModel;
using System.Threading;
using WebApplication2.Communication;
using WebApplication2.parsing;
using System.Collections.ObjectModel;
using System.Collections.Generic;

namespace WebApplication2.Models
{
    public class LogModel 
    {
        private Client client;
        private ParsingLog parsLog;
        public event EventHandler<string> update;
        public List<LogProperties> LogsList { get; set; }
        public LogModel()
        {

            LogsList = new List<LogProperties>();
            parsLog = new ParsingLog();
            LogsList.Add(new LogProperties("INFO", "vdv wejv jajkwvi qi"));
            LogsList.Add(new LogProperties("AAA", "jnkvdnsvnwnv jwidviw"));
            LogsList.Add(new LogProperties("HHH", "vdv vdiodvnd jajkwvi qi"));
            try
            {
                //client TCP
                client = Client.Instance;
                client.MessageRecieved += getMessage;
                Thread.Sleep(1000);
                // if the connection is successful, the background color will be white.
            }
            catch (Exception e)
            {
            }
        }
            
        /**
         * When an new message event happens this function activate.
         * The function handles messages related to the logs window.
         **/
        public void getMessage(Object sender, string message)
        {
            string[] msg = message.Split('#');
            // The history of the logs, which is obtained at the moment of connection to the server.
            if (string.Equals(msg[0], "logs"))
            {
                LogsList = parsLog.parsingLogs(message);
            }
            update.Invoke(this, "update");
        }
    }
}
