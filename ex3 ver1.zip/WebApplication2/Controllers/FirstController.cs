﻿using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;
using WebApplication2.Models;

namespace WebApplication2.Controllers
{
    public class FirstController : Controller
    {
        static ImageWebModel imageModel = new ImageWebModel();
        static LogModel logModel = new LogModel();
        static SettingsModel settingsModel = new SettingsModel();
        static PhotosModel photoModel= new PhotosModel();

        public FirstController()
        {
            logModel.update += onLogUpdate;
            settingsModel.update += onConfigUpdate;
        }

        public void onLogUpdate(Object sender, string message)
        {
            Logs();
        }

        public void onConfigUpdate(Object sender, string message)
        {
            int i = -1;
            Config(i);
        }

        // GET: First
        //יחפש בviews את השם 
        public ActionResult Index()
        {
            return View(imageModel);
        }

        public ActionResult Config(int numHandler)
        {
            if (numHandler != -1)
            {
                string handlerName = settingsModel.handlers[numHandler];
                settingsModel.DeleteHandler(handlerName);
            }
            ViewBag.Title = "Config";
            return View(settingsModel);
        }

        public ActionResult Logs()
        {
            ViewBag.Title = "Logs";
            return View(logModel);
        }

        public ActionResult viewImage(int numImage)
        {
            Photo photo = new Photo(photoModel.photos.Find(item => item.num == numImage).pathThumbnail, numImage);
            return View(photo);
        }

        public ActionResult deleteImage(int numImage)
        {
            Photo photo = new Photo(photoModel.photos.Find(item => item.num == numImage).pathThumbnail, numImage);
            return View(photo);
        }

        
        public ActionResult deleteHandler(int numHandler)
        {
            string handlerName = settingsModel.handlers[numHandler];
            Handler handler = new Handler(handlerName, numHandler);
            return View(handler);
        }

        public ActionResult Photos(int numImage)
        {
            if (numImage != -1)
            {
                photoModel.removePhoto(numImage);
            }
            return View(photoModel);
        }

        [HttpPost]
        public JObject GetLogByType(string type)
        {
            foreach (var empl in logModel.LogsList)
            {
                if (empl.Type == type)
                {
                    JObject data = new JObject();
                    data["Type"] = empl.Type;
                    data["Message"] = empl.Message;
                    return data;
                }
            }
            return null;
        }
    }
}
