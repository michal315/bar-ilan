﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using ImageService.Logging;
using ImageService.Logging.Modal;
using System.Text.RegularExpressions;
using System.Security.Permissions;


namespace ImageService
{
     public class DirectoryHandler : IDirectoryHandler
    {
        private IImageController controller;              // The Image Processing Controller
        private ILoggingService logging;
        private FileSystemWatcher dirWatcher;             // The Watcher of the Dir
        private string path;                              // The Path of directory
        // The Event That Notifies that the Directory is being closed
        public event EventHandler<DirectoryCloseEventArgs> DirectoryClose;

        /**
        * @arg logging - is used to write log in log file.
        * @arg controller - the controller has execute function will be used when I recieve command from dir watcher.  
        **/
        public DirectoryHandler(IImageController controller, ILoggingService logging) {
            this.logging = logging;
            this.controller = controller;
        }

      /**
       * @arg source.
       * @arg e.
       * When a new file is added to the listened directory, the watcher invoke an event, 
       * and this function will start operating.
       **/
        private void OnCreated(object source, FileSystemEventArgs e) {
            string file = e.Name;
            // filter file types 
            if (file.EndsWith(".jpg") || file.EndsWith(".bmp") || file.EndsWith(".gif") || file.EndsWith(".png")) { 
                string[] args = new string[2];
                args[0] = e.FullPath;
                args[1] = e.Name;
                bool result;
                string message = controller.ExecuteCommand(0, args, out result);
                if (result)
                {
                    this.logging.Log(message, MessageTypeEnum.INFO);
                }
                else
                {
                    this.logging.Log(message, MessageTypeEnum.FAIL);
                }
            } 
        }

        /**
         * @arg source.
         * @arg e.
         * When the listened directory will close, this function will start operating.
         **/
        private void OnClosed(object source, FileSystemEventArgs e) {
            DirectoryCloseEventArgs dirClose = new DirectoryCloseEventArgs(this.path, "close");
            DirectoryClose.Invoke(this, dirClose);
        }

        /**
         * @arg sender.
         * @arg e.
         * When the server will close, this function will start operating, it stops the watcher,
         * and write appropriate log.
         **/
        public void OnDirectoryClose(object sender, string dir) {
            if (dir == path) {
                try {
                    dirWatcher.EnableRaisingEvents = false;
                    this.logging.Log("directory "+ path + " closed", MessageTypeEnum.INFO);
                }
                catch (Exception ex) {
                    this.logging.Log(ex.Message, MessageTypeEnum.FAIL);
                }
            }
        }

        /**
         * @arg dirPath.
         * given a path to a directory the function creates a new directory watcher.
         **/
        public void StartHandleDirectory(string dirPath) {
            this.path = dirPath;
            this.dirWatcher = new FileSystemWatcher();
            dirWatcher.Path = path;
            // 'start' watching.
            dirWatcher.EnableRaisingEvents = true;
            // add 'OnCreated' function to listening to Created event.
            dirWatcher.Created += new FileSystemEventHandler(OnCreated);

        }
    }
}
