﻿using ImageService.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ImageService;
using System.Configuration;
using ImageService.Logging.Modal;
using communication.Server;
using System.Net.Sockets;
using MyService.ImageService.Commands;

namespace ImageService {
    class ImageServer {
        const int PORT = 50000;
        private IImageController controller;
        private ILoggingService logging;
        private Dictionary<string, DirectoryHandler> handlers;
        private Server server;
        // The event that notifies about a new Command being recieved
        public event EventHandler<string> closeDirectory;          
        
        public ImageServer(IImageController controller, ILoggingService logging) {
            this.handlers = new Dictionary<string, DirectoryHandler>();
            this.logging = logging;
            this.controller = controller;
            GetConfigCommand getConfig = new GetConfigCommand();
            // Listening to event closeDirectory, to remove the dir from the list of listening directory.
            closeDirectory += getConfig.removeHandler;
            controller.addICommand(getConfig, 1);
            createHandlers();
            // create tcp server
            server = new Server(PORT);
            // Listening to newConnection event and newMessage event
            server.newConnection += NewClient;
            server.newMessage += MessageReceived;
        }

     /**
      * creates directory handler for all paths that in the 'Handler' list.
      **/
        public void createHandlers() {
            string handlersList = ConfigurationManager.AppSettings["Handler"];
            string[] path = handlersList.Split(';');
            foreach (string onePath in path) {
                DirectoryHandler dHandler = new DirectoryHandler(controller, logging);
                dHandler.StartHandleDirectory(onePath);
                handlers.Add(onePath, dHandler);
                closeDirectory += dHandler.OnDirectoryClose;            // when server close.
                dHandler.DirectoryClose += OnHandlerClose;              // when handler close.
            }
        }

        /**
         *  when an newMessage event happens this function activates
         *  @args message - the message that received.
         **/
        private void MessageReceived(Object sender, string message) {
            string[] command = message.Split('#');
            if (command[0] == "closeDir")
            {
                DirectoryCloseEventArgs dc = new DirectoryCloseEventArgs(command[1], "");
                OnHandlerClose(this, dc);
            }
        }

        /**
         * when an newClient event happens this function activates
         * execute command of sent history logs, and sent app-config data.
         **/
        private void NewClient(Object sender, TcpClient client)
        {
            bool res;
            server.sendMessageByTcp(controller.ExecuteCommand(1, new string[1], out res), client);
            server.sendMessageByTcp(controller.ExecuteCommand(2, new string[1], out res), client);
        }

        /**
         * when an newLog event happens this function activates and
         * converts the message details to the string, according to the convention.
         **/
        public void onNewLog(Object sender, MessageRecievedEventArgs message)
        {
            string log = "log#";
            log += message.Status;
            log += "#";
            log += message.Message;
            server.sendMessage(log);
        }

       /**
        * close the server communication, and the dir watcher.
        **/
        public void closeServer() {
            foreach (KeyValuePair<string, DirectoryHandler> handler in handlers)
            {
                 this.closeDirectory.Invoke(this, handler.Key);
            }
            server.Stop();
        }

     /**
      * @arg sender.
      * @arg e - class that contains the directory name and the message.
      **/
        public void OnHandlerClose(object sender, DirectoryCloseEventArgs e) {
            foreach (KeyValuePair<string, DirectoryHandler> handler in handlers) {
                if (handler.Key == e.DirectoryPath) {
                    this.closeDirectory.Invoke(this, e.DirectoryPath);
                    closeDirectory -= handler.Value.OnDirectoryClose;
                    handlers.Remove(handler.Key);
                    break;
                }
            }
            server.sendMessage("closeDir#" + e.DirectoryPath);
        }
    }
}

