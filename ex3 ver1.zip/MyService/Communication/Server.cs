﻿using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.IO;

namespace communication.Server
{
    class Server
    {
        private Boolean isRunning;
        private TcpListener listener;
        private Dictionary<TcpClient, Tuple<NetworkStream, BinaryWriter>> clients;
        public event EventHandler<TcpClient> newConnection;
        public event EventHandler<string> newMessage;

        public Server(int port)
        {
            clients = new Dictionary<TcpClient, Tuple<NetworkStream, BinaryWriter>>();
            listener = new TcpListener(IPAddress.Parse("127.0.0.1"), port);
            isRunning = false;
            LoopClients();
        }

        /**
         *  The function activates a loop (in new task) that expects to receive new clients 
         *  over the time that the service is running.
         **/
        public void LoopClients()
        {
            listener.Start();
            isRunning = true;
            new Task(() =>
            {
                while (isRunning)
                {
                    // wait for client connection
                    TcpClient newClient = listener.AcceptTcpClient();
                    NetworkStream nwStream = newClient.GetStream();
                    BinaryWriter writer = new BinaryWriter(nwStream);
                    clients.Add(newClient, new Tuple<NetworkStream, BinaryWriter>(nwStream, writer));
                    Console.WriteLine("Got new connection");
                    // create a thread to handle communication
                    new Task(() =>
                    {
                        // invoke that new client connected.
                        newConnection.Invoke(this, newClient);
                        listenToClient(newClient);
                    }).Start();

                }
            }).Start();
        }

        /**
         * The function sends a message to a particular client
         * @args message - the message to send.
         * @args client - the specific client to whom the message is sent.
         **/
        public void sendMessageByTcp(string message, TcpClient client)
        {
            try
            {
                clients[client].Item2.Write(message);
            }
            // When an error occurs, the client is deleted from the list and closed.
            catch (Exception e)
            {
                clients[client].Item1.Close();
                clients[client].Item2.Close();
                client.Close();
                clients.Remove(client);
            }
            
            
        }

        /**
        * The function sends a message to all the clients
        * @args message - the message to send.
        **/
        public void sendMessage(string message)
        {
            foreach (TcpClient client in clients.Keys)
            {
                new Task(() =>
                {
                    try
                    {
                        clients[client].Item2.Write(message);
                    }
                    // When an error occurs, the client is deleted from the list and closed.
                    catch (Exception e)
                    {
                        clients[client].Item1.Close();
                        clients[client].Item2.Close();
                        client.Close();
                        clients.Remove(client);
                    }
                }).Start();
            } 
        }

        /**
         * The function accepts a client as argument, in a separate task tries to receive 
         * messages from client as long as the client is connected. 
         **/
        public void listenToClient(TcpClient client)
        {
            new Task(() =>
            {
                BinaryReader reader = new BinaryReader(clients[client].Item1);
                string message;
                while (isRunning)
                {
                    try
                    {
                        message = reader.ReadString();
                    }  
                    // When an error occurs, the client is deleted from the list and closed.
                    catch (Exception e)
                    {
                        clients[client].Item1.Close();
                        clients[client].Item2.Close();
                        client.Close();
                        clients.Remove(client);
                        return;
                    }
                    // when message received new message event invoke the message. 
                    newMessage.Invoke(this, message);
                }
            }).Start();
        }

        /**
         * The function handles the closing of the server, closing the clients.
         **/
        public void Stop() {
            isRunning = false;
            foreach (TcpClient client in clients.Keys)
            {
                clients[client].Item1.Close();
                clients[client].Item2.Close();
                client.Close();
            }
            listener.Stop();
        }
    }
}

