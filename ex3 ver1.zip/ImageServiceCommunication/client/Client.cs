﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.IO;

namespace ImageServiceGui.Communication.client {
    class Client {
        public event EventHandler<string> MessageRecieved;
        private static Client instance;

        TcpClient client;

        public static Client Instance {
            get {
                if (instance == null) {
                    instance = new Client();
                    instance.connect();
                }
                return instance;
            }
        }

        public void connect() {
            IPEndPoint ep = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 8000);
            client = new TcpClient();
            client.Connect(ep);
            Console.WriteLine("You are connected"); 
        }


        public void start() {
            while (true) {
                read();
            }
        }

        public string read() {
            string result;
            using (NetworkStream stream = client.GetStream())
            using (BinaryReader reader = new BinaryReader(stream))
            {
                // Get result from server
                result = reader.ReadString();
                Console.WriteLine(result);
                MessageRecieved.Invoke(this, result);
            }
            return result;
        }

        public void write(string command)
        {
            using (NetworkStream stream = client.GetStream())
             using (BinaryWriter writer = new BinaryWriter(stream))
             {
                 // Send data to server
                 Console.Write(command);
                 int num = int.Parse(Console.ReadLine());
                 writer.Write(num);
             }
        }

        public void disconnect() {
            client.Close();
        }



    }
}
