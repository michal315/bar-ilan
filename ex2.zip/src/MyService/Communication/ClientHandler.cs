﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.IO;
using ImageService.Logging.Modal;

namespace communication.Server
{
    class ClientHandler : IClientHandler
    {
        public event EventHandler<string> MessageReceived;
        public event EventHandler<TcpClient> newConnection;
        public ClientHandler()
        {
            
        }
        public void HandleClient(TcpClient client)
        {
            Console.WriteLine("in handle");
            new Task(() =>
            {
                onNewClient(client);
                while (true)
                {
                    NetworkStream stream = client.GetStream();
                    StreamReader reader = new StreamReader(stream);
                    string commandLine = reader.ReadLine();
                    if (commandLine == "close")
                    {
                        client.Close();
                        return;
                    } else {
                        onMessageReceived(commandLine);
                    }
                }
                
                
                //StreamWriter writer = new StreamWriter(stream);
                
                //Console.WriteLine("Got command: {0}", commandLine);
                //writer.Write("jj");
            }).Start();
        }

        public void onMessageReceived(string message)
        {
            MessageReceived.Invoke(this, message);
        }

        public void onNewClient(TcpClient client)
        {
            Console.WriteLine("1. on new client");
            newConnection.Invoke(this, client);
        }
    }
}