﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.IO;

namespace ImageServiceGui.Communication.client {

    class Client {
        public event EventHandler<string> MessageRecieved;
        private static Client instance;
        private TcpClient client;
        private NetworkStream stream;
        private BinaryReader reader;
        private BinaryWriter writer;

        public static Client Instance {
            get {
                if (instance == null) {
                    instance = new Client();
                    instance.connect();
                }
                return instance;
            }
        }

        public void connect() {
            IPEndPoint ep = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 50000);
            client = new TcpClient();
            client.Connect(ep);
            Console.WriteLine("You are connected");
            stream = client.GetStream();
            reader = new BinaryReader(stream);
            writer = new BinaryWriter(stream);
            start();
        }


        public void start() {
            new Task(() =>
            {
                while (true)
                {
                    read();
                }
            }).Start();
        }

        public void read() {
            string result;
            try {
                result = reader.ReadString();
                MessageRecieved.Invoke(client, result);
            }
            catch (Exception e)
            {
                   
            }            
        }

        public void write(string command)
        {
            try
            {
                writer.Write(command);
                Console.WriteLine(command);
            }
            catch (Exception e)
            {

            }
             
        }

        public void disconnect() {
            client.Close();
        }
    }
}
