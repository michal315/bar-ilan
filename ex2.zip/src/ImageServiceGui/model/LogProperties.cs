﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageServiceGui.model
{
    class LogProperties
    {
        private string type;
        private string message;
        private string color;

        public LogProperties(string _type, string _message)
        {
            this.type = _type;
            this.message = _message;
                switch (type)
            {
                case "INFO":
                    color = "#7CFC00";
                    break;
                case "FAIL":
                    color = "#F08080";
                    break;
                case "WARNING":
                    color = "#FFFF00";
                    break;
            }
        }

        public string Type
        {
            get { return type; }
            set { type = value; }
        }

        public string Message
        {
            get { return message; }
            set { message = value; }
        }
        public string Color
        {
            get { return color; }
            set { color = value; }
        }

    }
}
