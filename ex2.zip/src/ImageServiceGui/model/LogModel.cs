﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Threading;
using ImageServiceGui.Communication.client;
using ImageServiceGui.parsing;
using System.Collections.ObjectModel;
using System.Windows.Threading;

namespace ImageServiceGui.model
{
    class LogModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private Client client;
        ObservableCollection<LogProperties> m_logs;
        ParsingLog parsLog;
        private string m_connect;

        public LogModel()
        {
            parsLog = new ParsingLog();
            m_logs = new ObservableCollection<LogProperties>();
            Object locker = new Object();
            System.Windows.Data.BindingOperations.EnableCollectionSynchronization(m_logs, locker);
            try
            {
                //client TCP
                client = Client.Instance;
                client.MessageRecieved += getMessage;
                Thread.Sleep(1000);
                connect = "White";
            } catch (Exception e)
            {
                connect = "Gray";
            }

}

        public ObservableCollection<LogProperties> logs
        {
            set
            {
                m_logs = value;
                NotifyPropertyChanged("logs");
            }
            get { return m_logs; }
        }

        public string connect
        {
            set
            {
                m_connect = value;
                NotifyPropertyChanged("connect");
            }
            get { return m_connect; }
        }

        void disconnect()
        {
            client.disconnect();
        }

        public void getMessage(Object sender, string message)
        {
            string[] msg = message.Split('#');
            if (string.Equals(msg[0], "log"))
            {
                LogProperties lp = parsLog.parsingLog(message);
                App.Current.Dispatcher.Invoke((Action)(() => m_logs.Add(lp)));
                NotifyPropertyChanged("logs");
            }
            if (string.Equals(msg[0], "logs"))
            {
                m_logs = parsLog.parsingLogs(message);
            }
        }

        public void NotifyPropertyChanged(string propName)
        {
            if (this.PropertyChanged != null)
                this.PropertyChanged(this, new PropertyChangedEventArgs(propName));
        }

    }
}
