﻿using ImageServiceGui.model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageServiceGui.parsing
{
    class ParsingLog
    {

        public ObservableCollection<LogProperties> parsingLogs(string message)
        {
            ObservableCollection <LogProperties> logs = new ObservableCollection<LogProperties>();
            string[] msg = message.Split('#');
            for (int i = 1; i < msg.Length && i + 1 < msg.Length; i += 2)
            {
                LogProperties newlog = new LogProperties(msg[i], msg[i + 1]);
                logs.Add(newlog);
            }
            return logs;
        }

        public LogProperties parsingLog(string message)
        {
            string[] msg = message.Split('#');
            return new LogProperties(msg[1], msg[2]); 
        }
    }
}
