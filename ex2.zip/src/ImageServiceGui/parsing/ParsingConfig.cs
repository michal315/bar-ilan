﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ImageServiceGui.model;

namespace ImageServiceGui.parsing {
    class ParsingConfig {

        private SettingsModel settingsModel;
        public ParsingConfig(SettingsModel sModel) {
            this.settingsModel = sModel;
        }

        public void parse(string settings) {
            Console.WriteLine("in parse");
            string[] config = settings.Split('#');
            if (config[1] != null)
            {
                settingsModel.outputDirectory = config[1];
            }
            if (config[2] != null)
            {
                settingsModel.sourceName = config[2];
            }
            if (config[3] != null)
            {
                settingsModel.logName = config[3];
            }
            if (config[4] != null)
            {
                settingsModel.thumbnailSize = config[4];
            }
            if (config[5] != null)
            {
                ObservableCollection<string> h = new ObservableCollection<string>();
                string[] handlers = config[5].Split(';');
                foreach (string handler in handlers) {
                    h.Add(handler);
                }
                settingsModel.handlers = h;
            }
        }
    }
}
