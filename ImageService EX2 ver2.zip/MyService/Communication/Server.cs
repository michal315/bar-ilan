﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;

namespace communication.Server
{
    class Server
    {
        private Boolean isRunning;
        private TcpListener listener;
        private IClientHandler ch;
        private Dictionary<TcpClient, Tuple<NetworkStream, BinaryWriter>> clients;
        public event EventHandler<TcpClient> newConnection;
        public event EventHandler<string> newMessage;

        public Server(int port, IClientHandler ch)
        {
            clients = new Dictionary<TcpClient, Tuple<NetworkStream, BinaryWriter>>();
            this.ch = ch;
            listener = new TcpListener(IPAddress.Parse("127.0.0.1"), port);
            isRunning = false;
            LoopClients();
        }

        public void LoopClients()
        {
            listener.Start();
            isRunning = true;
            new Task(() =>
            {
                while (isRunning)
                {
                    // wait for client connection
                    TcpClient newClient = listener.AcceptTcpClient();
                    NetworkStream nwStream = newClient.GetStream();
                    BinaryWriter writer = new BinaryWriter(nwStream);
                    clients.Add(newClient, new Tuple<NetworkStream, BinaryWriter>(nwStream, writer));
                    Console.WriteLine("Got new connection");
                    // create a thread to handle communication
                    new Task(() =>
                    {
                        newConnection.Invoke(this, newClient);
                        //ch.HandleClient(newClient);
                    }).Start();

                }
            }).Start();
        }
       
        public void sendMessageByTcp(string message, TcpClient client)
        {
            try
            {
                clients[client].Item2.Write(message);
            }
            catch (Exception e)
            {
                clients.Remove(client);
                client.Close();
            }
            
            
        }

        public void sendMessage(string message)
        {
       /**     foreach (TcpClient client in clients.Keys)
            {
                new Task(() =>
                {
                    try
                    {
                        clients[client].Item2.Write(message);
                    }
                    catch (Exception e)
                    {
                        clients.Remove(client);
                        client.Close();
                    }
                }).Start();
            } **/
        }


        public void listenToClient(TcpClient client)
        {
            new Task(() =>
            {
                StreamReader reader = new StreamReader(clients[client].Item1);
                string message;
                while (isRunning)
                {
                    try
                    {
                        message = reader.ReadLine();
                    } catch (Exception e)
                    {
                        clients.Remove(client);
                        client.Close();
                        return;
                    }
                    newMessage.Invoke(this, message);
                }
            }).Start();
        }

        public void Stop() {
            isRunning = false;
            foreach (TcpClient client in clients.Keys)
            {
                clients[client].Item1.Close();
                clients[client].Item2.Close();
                client.Close();
            }
            listener.Stop();
        }
    }
}

