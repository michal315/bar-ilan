﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageService {
    public interface ICommand {
        /**
        * @arg args - is used by the function that will execute.
        * @arg result - Failure or success.   
        **/
        string Execute(string[] args, out bool result);          
    }
}
