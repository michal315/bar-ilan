﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ImageService;
using ImageService.Logging;
using ImageService.Logging.Modal;


namespace MyService.ImageService.Commands
{
    class LogCommand : ICommand
    {
        ILoggingService _logging;
        public LogCommand(ILoggingService logging)
        {
            _logging = logging;
        }

        public string Execute(string[] args, out bool result)
        {
            result = true;
            string allLogs = "logs#";
            LinkedList<MessageRecievedEventArgs> logs = _logging.getLogs();
            foreach (MessageRecievedEventArgs log in logs)
            {
                allLogs += log.Status;
                allLogs += "#";
                allLogs += log.Message;
                allLogs += "#";
            }
            return allLogs;
        }
    }
}
