﻿using ImageService.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ImageService;
using System.Configuration;
using ImageService.Logging.Modal;
using communication.Server;
using System.Net.Sockets;

namespace ImageService {
    class ImageServer {
        const int PORT = 50000;
        private IImageController controller;
        private ILoggingService logging;
        private Dictionary<string, DirectoryHandler> handlers;
        private Server server;
        // The event that notifies about a new Command being recieved
        public event EventHandler<CommandRecievedEventArgs> CommandRecieved;          
        
        public ImageServer(IImageController controller, ILoggingService logging) {
            this.handlers = new Dictionary<string, DirectoryHandler>();
            this.logging = logging;
            this.controller = controller; 
            createHandlers();

            // create tcp server
            ClientHandler ch = new ClientHandler();
            // ch.MessageReceived += MessageReceived;
            //ch.newConnection += NewClient;
            server = new Server(PORT, ch);
            server.newConnection += NewClient;
            server.newMessage += MessageReceived;
        }

     /**
      * creates directory handler for all paths that in the 'Handler' list  
      **/
        public void createHandlers() {
            string handlersList = ConfigurationManager.AppSettings["Handler"];
            string[] path = handlersList.Split(';');
            foreach (string onePath in path) {
                DirectoryHandler dHandler = new DirectoryHandler(controller, logging);
                dHandler.StartHandleDirectory(onePath);
                handlers.Add(onePath, dHandler);
                CommandRecieved += dHandler.OnCommandRecieved;          // when server close.
                dHandler.DirectoryClose += OnHandlerClose;              // when handler close.
            }
        }

        private void MessageReceived(Object sender, string message) {
            bool res;
            string[] command = message.Split('#');
            if (command[0] == "removeDir")
            {
                DirectoryCloseEventArgs dc = new DirectoryCloseEventArgs(command[1], "");
                OnHandlerClose(this, dc);
            }
        }

        private void NewClient(Object sender, TcpClient client)
        {
            bool res;
            server.sendMessageByTcp(controller.ExecuteCommand(1, new string[1], out res), client);
            server.sendMessageByTcp(controller.ExecuteCommand(2, new string[1], out res), client);
        }

        public void onNewLog(Object sender, MessageRecievedEventArgs message)
        {
            string log = "log#";
            log += message.Status;
            log += "#";
            log += message.Message;
            server.sendMessage(log);
        }

        public void closeServer() {
            string[] args = new string[2];
            args[0] = "close";
            foreach (KeyValuePair<string, DirectoryHandler> handler in handlers)
            {
                 CommandRecievedEventArgs newCommand = new CommandRecievedEventArgs(0, args,handler.Key);
                 this.CommandRecieved.Invoke(this, newCommand);
            }
        }

     
        public void sendCommand() {
            string[] args = new string[2];
            args[0] = "command";
            foreach (KeyValuePair<string, DirectoryHandler> handler in handlers) {
                CommandRecievedEventArgs newCommand = new CommandRecievedEventArgs(0, args, handler.Key);
                this.CommandRecieved.Invoke(this, newCommand);
            }
        }

     /**
      * @arg sender.
      * @arg e - class that contains the directory name and the message.
      **/
        public void OnHandlerClose(object sender, DirectoryCloseEventArgs e) {
            foreach (KeyValuePair<string, DirectoryHandler> handler in handlers) {
                if (handler.Key == e.DirectoryPath) {
                    CommandRecieved -= handler.Value.OnCommandRecieved;
                    handlers.Remove(handler.Key);
                    return;
                }
            }
        }
    }
}

