﻿using ImageServiceGui.model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageServiceGui.parsing
{
    class ParsingLog
    {

        public ObservableCollection<LogProperties> parsingLogs(string message)
        {
            ObservableCollection <LogProperties> logs = new ObservableCollection<LogProperties>();
            string[] msg = message.Split('#');
            for (int i = 1; i < msg.Length && i + 1 < msg.Length; i += 2)
            {
                LogProperties newlog = new LogProperties(msg[i], msg[i + 1]);
                logs.Add(newlog);
            }
            return logs;
        }

        public LogProperties parsingLog(string message)
        {
            string[] msg = message.Split('#');
            return new LogProperties(msg[1], msg[2]); 
        }


        /**
        public List<Tuple<string, string>> parsingLogs (string message)
        {
            List<Tuple<string, string>> logs = new List<Tuple<string, string>>();
            string[] msg = message.Split('#');
            for (int i = 1; i < msg.Length && i + 1 < msg.Length; i+=2)
            {
                logs.Add(new Tuple<string, string>(msg[i], msg[i + 1]));
            }
            return logs;
        }

        public Tuple<string, string> parsingLog(string message)
        {
            string[] msg = message.Split('#');
            return new Tuple<string, string>(msg[1], msg[2]);
        }
        **/
    }
}
