﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using ImageServiceGui.model;
using Microsoft.Practices.Prism.Commands;
using System.Diagnostics;
using System.Windows.Input;

namespace ImageServiceGui.viewModel
{
    class SettingsViewModel : INotifyPropertyChanged {
        public event PropertyChangedEventHandler PropertyChanged;
        private SettingsModel model;
        public string VM_dirToClose = null;

        public SettingsViewModel(SettingsModel model) {
            this.model = model;
            model.PropertyChanged += delegate(Object sender, PropertyChangedEventArgs e)
            {

                NotifyPropertyChanged("VM_" + e.PropertyName);
            };
        }

        public ICommand removeCommand { get; private set; }

        private void OnRemove(object obj)
        {
           // todo
        }

        private bool CanRemove(object obj)
        {
            if (string.IsNullOrEmpty(VM_dirToClose))
            {
                return false;
            }
            return true;
        }
        
        public void NotifyPropertyChanged(string propName) {
            if (this.PropertyChanged != null)
                this.PropertyChanged(this, new PropertyChangedEventArgs(propName));
        }

        public string VM_outputDirectory {
            get { return model.outputDirectory; }
        }
        public string VM_sourceName {
            get { return model.sourceName; }
        }
        public string VM_logName {
            get { return model.logName; }
        }
        public int VM_thumbnailSize {
            get { return model.thumbnailSize; }
        }
        public List<string> VM_handlers {
            get { return model.handlers; }
        }

        public string dirToClose {
            set {
                dirToClose = value;
                NotifyPropertyChanged("dirToClose");
            }
            get { return VM_dirToClose; }
        } 

    }
}
