﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Threading;
using ImageServiceGui.Communication.client;
using ImageServiceGui.parsing;

namespace ImageServiceGui.model {
    class SettingsModel : INotifyPropertyChanged {

        public event PropertyChangedEventHandler PropertyChanged;
        event EventHandler<string> MessageRecieved;
        private Client client;
        private ParsingConfig parse;
        private string m_outputDirectory;
        private string m_sourceName;
        private string m_logName;
        private int m_thumbnailSize;
        private List<string> m_handlers;


        public SettingsModel() {
            parse = new ParsingConfig(this);
            //client TCP
            client = Client.Instance;
            client.MessageRecieved += getMessage;
     
            m_outputDirectory = "fcefcecre";
            m_sourceName = "eececec";
            m_logName = "dvsdvdav";
            m_thumbnailSize = 5;
        //    m_handlers = new string[2];
         //   m_handlers[0] = "ffffss";
          //  m_handlers[1] = "fewcq";
        }

        public string outputDirectory {
            set {m_outputDirectory = value;
                NotifyPropertyChanged("outputDirectory");}
            get { return m_outputDirectory; }
        }
        public string sourceName {
            set {
                m_sourceName = value;
                NotifyPropertyChanged("sourceName");}
            get { return m_sourceName; }
        }
        public string logName {
            set {
                m_logName = value;
                NotifyPropertyChanged("logName");}
            get { return m_logName; }
        }
        public int thumbnailSize {
            set {
                m_thumbnailSize = value;
                NotifyPropertyChanged("thumbnailSize");
            }
            get { return m_thumbnailSize; }
        }
        public List<string> handlers {
            set {
                m_handlers = value;
                NotifyPropertyChanged("handlers");
            }
            get { return m_handlers; }
        }


        void disconnect() {
            client.disconnect();
        }

        // from view - close dir.
        public void closeHandler(Object sender, string handler) {
            client.write("close " + handler);
        }

        // from server
        public void getMessage(Object sender, string message) {
            Console.WriteLine("get massega settings model");
            string[] msg = message.Split('#');
            if (string.Equals(msg[0], "config")) {
                parse.parse(message);
            }
        }

        public void NotifyPropertyChanged(string propName) {
            if (this.PropertyChanged != null)
                this.PropertyChanged(this, new PropertyChangedEventArgs(propName));
        }

    }
}
