﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Threading;
using ImageServiceGui.Communication.client;
using ImageServiceGui.parsing;
using System.Collections.ObjectModel;

namespace ImageServiceGui.model
{
    class LogModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private Client client;
        // List<Tuple<string, string>> m_logs;
        ObservableCollection<LogProperties> m_logs;
        ParsingLog parsLog;

        public LogModel()
        {
            parsLog = new ParsingLog();
            m_logs = new ObservableCollection<LogProperties>();
            //m_logs = new List<Tuple<string, string>>();
            //client TCP
            client = Client.Instance;
            client.MessageRecieved += getMessage;
        }

        /** public List<Tuple<string, string>> logs
         {
             set
             {
                 m_logs = value;
                 NotifyPropertyChanged("outputDirectory");
             }
             get { return m_logs; }
         }**/

        public ObservableCollection<LogProperties> logs
        {
            set
            {
                m_logs = value;
                NotifyPropertyChanged("logs");
            }
            get { return m_logs; }
        }

        void disconnect()
        {
            client.disconnect();
        }

        public void getMessage(Object sender, string message)
        {
            string[] msg = message.Split('#');
            if (string.Equals(msg[0], "log"))
            {
                m_logs.Add(parsLog.parsingLog(message));
                NotifyPropertyChanged("logs");
            }
            if (string.Equals(msg[0], "logs"))
            {
                m_logs = parsLog.parsingLogs(message);
            }
        }

        public void NotifyPropertyChanged(string propName)
        {
            if (this.PropertyChanged != null)
                this.PropertyChanged(this, new PropertyChangedEventArgs(propName));
        }

    }
}
