﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageServiceGui.model
{
    class LogProperties
    {
        private string type;
        private string message;
        private int color;

        public LogProperties(string _type, string _message)
        {
            this.type = _type;
            this.message = _message;
                switch (type)
            {
                case "Info":
                    color = 33;
                    break;
                case "Error":
                    color = 33;
                    break;
                default:
                    color = 33;
                    break;
            }
        }

        public string Type
        {
            get { return type; }
            set { type = value; }
        }

        public string Message
        {
            get { return message; }
            set { message = value; }
        }
        public int Color
        {
            get { return color; }
            set { color = value; }
        }

    }
}
