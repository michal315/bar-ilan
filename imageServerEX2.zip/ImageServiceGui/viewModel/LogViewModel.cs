﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using ImageServiceGui.model;

namespace ImageServiceGui.viewModel
{
    class LogViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private SettingsModel model;
        public LogViewModel(SettingsModel model)
        {
            this.model = model;

        }
    }
}
