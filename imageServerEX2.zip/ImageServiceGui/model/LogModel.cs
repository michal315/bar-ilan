﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel;
using System.Threading;
using ImageServiceGui.Communication.client;
using ImageServiceGui.parsing;

namespace ImageServiceGui.model
{
    class LogModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private Client client;
        private ParsingConfig parse;
        // logs[0] = type, logs[1] = message.
        List<string[]> m_logs = new List<string[]>();

        public LogModel()
        {
            //client TCP
            client = Client.Instance;
            client.MessageRecieved += getMessage;
            string[] log1 = new string[2];
            string[] log2 = new string[2];
            string[] log3 = new string[2];
            log1[0] = "info";
            log1[1] = "log1 sddcsdchjbdshcbdhsb jsbchjbshjcbsj hjcsabhba";
            log2[0] = "info";
            log1[1] = "log2 sddcsdchjbdshcbdhsb jsbchjbshjcbsj hjcsabhba";
            log2[0] = "info";
            log1[1] = "log3 sddcsdchjbdshcbdhsb jsbchjbshjcbsj hjcsabhba";
            m_logs.Add(log1);
            NotifyPropertyChanged("outputDirectory");
            m_logs.Add(log2);
            NotifyPropertyChanged("outputDirectory");
            m_logs.Add(log3);
        }

        public List<string[]> outputDirectory
        {
            set
            {
                m_logs = value;
                NotifyPropertyChanged("outputDirectory");
            }
            get { return m_logs; }
        }

        void disconnect()
        {
            client.disconnect();
        }

        public void getMessage(Object sender, string message)
        {
            string[] msg = message.Split('#');
            if (string.Equals(msg[0], "log"))
            {
                string[] newLog = new string[2];
                newLog[0] = msg[1];
                newLog[1] = msg[2];
                m_logs.Add(newLog);
                NotifyPropertyChanged("logs");
            } else if (string.Equals(msg[0], "logs")) {
                for (int i = 1 ; i > msg.Length && i + 1 > msg.Length ; i+=2)
                {
                    string[] log1 = new string[2];
                    log1[0] = msg[i];
                    log1[1] = msg[i + 1];
                    m_logs.Add(log1);
                    NotifyPropertyChanged("logs");
                }
            }

        }

        public void NotifyPropertyChanged(string propName)
        {
            if (this.PropertyChanged != null)
                this.PropertyChanged(this, new PropertyChangedEventArgs(propName));
        }

    }
}
