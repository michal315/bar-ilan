﻿using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using ImageServiceGui.model;
using ImageServiceGui.Communication.client;
using ImageServiceGui.viewModel;
using System.ComponentModel;

namespace ImageServiceGui.view
{
    /// <summary>
    /// Interaction logic for Settings.xaml
    /// </summary>
    public partial class Settings : UserControl, INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;
        private SettingsViewModel settingsVM;
        public Settings() {
            InitializeComponent();
            SettingsModel sm = new SettingsModel();
            settingsVM = new SettingsViewModel(sm);
            settingsVM.PropertyChanged += onPropertyChanged;
            DataContext = settingsVM;
            //listBox.ItemsSource = settingsVM.VM_handlers;

            //UpdateHandlers();
        }

        private void UpdateHandlers()
        {
            if (settingsVM.VM_handlers != null)
            {
               // for (int i = 0; i < settingsVM.VM_handlers.Length; i++)
                //{
                   
                    //ListBoxItem newItem = new ListBoxItem();
                    //newItem.Content = settingsVM.VM_handlers[i];
                    //listBox.Items.Add(newItem);
                //}
            } 
  
        }

        private void onPropertyChanged(object sender, PropertyChangedEventArgs prop)
        {
            if (prop.PropertyName == "VM_handlers")
            {
                Console.WriteLine("PropertyChanged");
               
                //UpdateHandlers();
            }
        }

        private void listBox_SelectionChanged(object sender, SelectionChangedEventArgs e) {
           
        }

        private void Button_Click(object sender, RoutedEventArgs e) {

        }
    }
}
