﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ImageServiceGui.view
{
    /// <summary>
    /// Interaction logic for Logs.xaml
    /// </summary>
    public partial class Logs : UserControl
    {
        private DataRow dr;
        private DataTable dt;
        public Logs()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e) {
            dt = new DataTable("emp");
            DataColumn dc1 = new DataColumn("Type", typeof(int));
            DataColumn dc2 = new DataColumn("Message", typeof(string));
            dt.Columns.Add(dc1);
            dt.Columns.Add(dc2);
            dg.ItemsSource = dt.DefaultView;
        }
    }
}
