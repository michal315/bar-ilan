﻿using System;
using System.Threading.Tasks;
using System.Net;
using System.Net.Sockets;
using System.IO;
using System.Threading;

namespace WebApplication2.Communication {

    class Client {
        public event EventHandler<string> MessageRecieved;
        private static Client instance;
        private TcpClient client;
        private NetworkStream stream;
        private BinaryReader reader;
        private BinaryWriter writer;

        /**
         * This static function creates a single instance of a client that returns it.
         **/
        public static Client Instance {
            get {
                if (instance == null) {
                    instance = new Client();
                    instance.connect();
                }
                return instance;
            }
        }

        public void connect() {
            // create tcp client connection.
            IPEndPoint ep = new IPEndPoint(IPAddress.Parse("127.0.0.1"), 50000);
            client = new TcpClient();
            client.Connect(ep);
            stream = client.GetStream();
            // opent reader and writer.
            reader = new BinaryReader(stream);
            writer = new BinaryWriter(stream);
            start();
        }

        /**
         * The function creates a new task that expects to receive messages from the server.
         **/
        public void start() {
            new Task(() =>
            {
                while (true)
                {
                    string result;
                    try
                    {
                        result = reader.ReadString();
                        Thread.Sleep(2000);
                        // when messsage received MessageRecieved invoke. 
                        MessageRecieved.Invoke(client, result);
                    }
                    catch (Exception e)
                    {
                        disconnect();
                    }
                }
            }).Start();
        }

        /**
         * The function writes the message to the server.
         * @ param message.
         **/
        public void write(string command)
        {
            try
            {
                writer.Write(command);
                Console.WriteLine(command);
            }
            catch (Exception e)
            {
                disconnect();
            }
             
        }

        public void disconnect() {
            stream.Close();
            reader.Close();
            writer.Close();
            client.Close();
        }
    }
}
