﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Drawing;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Web;


namespace WebApplication2.Models
{
    public class Photo
    {
        
        private static Regex r = new Regex(":");
        /**
         * the class contains all the pic details. 
         **/
        public Photo(string _thumbnailpath,int _num)
        {
            num = _num;
            pathThumbnail = _thumbnailpath;
            // delete "thumbnail\" from the path and so we will get the regolar path.
            string[] res = _thumbnailpath.Split(new string[] { "thumbnail\\" }, StringSplitOptions.None);
            path = res[0] + res[1];
            Name = Path.GetFileName(path);
            string[] s = path.Split('\\');
            Date = s[s.Length - 2] + '/' + s[s.Length - 3];
        }

        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "path")]
        public string path { get; set; }

        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "pathThumbnail")]
        public string pathThumbnail { get; set; }

        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "Name")]
        public string Name { get; set; }

        [Required]
        [DataType(DataType.Text)]
        [Display(Name = "Date")]
        public string Date { get; set; }

        public int num { get; set; }
    }
}