﻿using System;
using System.Windows.Threading;
using System.ComponentModel;
using System.Threading;
using WebApplication2.Communication;
using WebApplication2.parsing;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace WebApplication2.Models
{
    public class LogModel 
    {
        private Client client;
        private ParsingLog parsLog;
        public event EventHandler<string> update;
        public List<LogProperties> LogsList { get; set; }
        public List<LogProperties> logByType { get; set; }
        [Required]
        public string type { get; set; }
       

        public LogModel()
        {
            type = "";
            LogsList = new List<LogProperties>();
            logByType = new List<LogProperties>();
            parsLog = new ParsingLog();
            try
            {
                //client TCP
                client = Client.Instance;
                client.MessageRecieved += getMessage;
            }
            catch (Exception e)
            {
            }
        }
            
        /**
         * When an new message event happens this function activate.
         * The function handles messages related to the logs window.
         **/
        public void getMessage(Object sender, string message)
        {
            string[] msg = message.Split('#');
            // The history of the logs, which is obtained at the moment of connection to the server.
            if (string.Equals(msg[0], "logs"))
            {
                LogsList = parsLog.parsingLogs(message);
            }
            update.Invoke(this, "update");
        }

        /**
         * the function makes a new List of logs that have the wanted type.
         **/
        public void makeLogByType()
        {
            logByType = new List<LogProperties>();
            for (int i = 0; i < LogsList.Count; i++)
            {
                if (LogsList[i].Type == type)
                {
                    logByType.Add(LogsList[i]);
                }
            } 
        }
        
        /**
         * The function adds a log the log list. 
         **/
        public void addLog(string type, string Message)
        {
            LogsList.Add(new LogProperties(type, Message));
            // invoke that the list was update
            update.Invoke(this, "update");
        }
    }
}
