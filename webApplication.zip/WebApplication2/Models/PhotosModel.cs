﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading;
using System.Web;
using System.Web.Hosting;

namespace WebApplication2.Models
{
    public class PhotosModel
    {
        public List<string> imagesPath { get; set; }
        public List<Photo> photos { get; set; }
        public PhotosModel()
        {
            imagesPath = new List<string>();
            photos = new List<Photo>();
            getImagesPath();
        }

        /**
         * the function opens the output directory and craets list of all the path 
         * that are in the durectory and sub directory. 
         **/
        private void getImagesPath()
        {
            string s = HostingEnvironment.MapPath("~/" + "/resource/output/thumbnail");
            imagesPath = Directory.GetFiles(s, "*.jpg", SearchOption.AllDirectories).ToList();
            imagesPath.AddRange(Directory.GetFiles(s, "*.png", SearchOption.AllDirectories).ToList());
            imagesPath.AddRange(Directory.GetFiles(s, "*.gif", SearchOption.AllDirectories).ToList());
            imagesPath.AddRange(Directory.GetFiles(s, "*.bmp", SearchOption.AllDirectories).ToList());
            for (int i = 0; i < imagesPath.Count; i++)
            {
                string[] res = imagesPath[i].Split(new string[] { "output" }, StringSplitOptions.None);
                imagesPath[i] = VirtualPathUtility.ToAbsolute("~/" + "/resource/output") + res[1];
                Photo newPhoto = new Photo(imagesPath[i], i);
                photos.Add(newPhoto);
            }
        }

        /**
         * the function receives number of pic and remoove the pic 
         * from the list and from the output directory  
         **/
        public void removePhoto(int numOfPhoto)
        {
            for (int i = 0; i < photos.Count; i++)
            {
                if (photos[i].num == numOfPhoto)
                {                   
                    File.Delete(HostingEnvironment.MapPath("~/" + photos[i].path));
                    File.Delete(HostingEnvironment.MapPath("~/" + photos[i].pathThumbnail));
                    photos.RemoveAt(i);
                    break;
                }
            }
        }
    }
}