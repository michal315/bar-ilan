package com.example.rachelherzlich.imageservicemobile;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.wifi.WifiManager;
import android.os.IBinder;
import android.widget.Toast;


public class ImageServiceMobile extends Service  {
    ImageModel model;
    BroadcastReceiver receiver;


    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Toast.makeText(this, "the service start", Toast.LENGTH_SHORT).show();
        model = new ImageModel(this);
        wifiConnection();
        return(START_STICKY);

    }
    @Override
    public void onDestroy() {
        // stop the broadcastReceiver.
        unregisterReceiver(receiver);
        Toast.makeText(this, "the service stop", Toast.LENGTH_SHORT).show();
        super.onDestroy();
    }

    /**
     * Subscribe as a listener for your device's wifi connection.
     * When there is a wifi connection, the images are sent.
     */
    private void wifiConnection() {
        final IntentFilter theFilter = new IntentFilter();
        theFilter.addAction("android.net.wifi.supplicant.CONNECTION_CHANGE");
        theFilter.addAction("android.net.wifi.STATE_CHANGE");
        this.receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                WifiManager wifiManager = (WifiManager) context.getSystemService(Context.WIFI_SERVICE);
                NetworkInfo networkInfo = intent.getParcelableExtra(WifiManager.EXTRA_NETWORK_INFO);
                if (networkInfo != null) {
                    if (networkInfo.getType() == ConnectivityManager.TYPE_WIFI) {
                        if (networkInfo.getState() == NetworkInfo.State.CONNECTED) {
                            // Starting the Transfer
                            model.start();
                        }
                    }
                }
            }
        };
        this.registerReceiver(this.receiver, theFilter);
    }
}
