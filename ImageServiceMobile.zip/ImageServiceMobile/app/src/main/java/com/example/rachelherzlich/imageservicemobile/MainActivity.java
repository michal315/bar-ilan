package com.example.rachelherzlich.imageservicemobile;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;


public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    public void onClickStart(View v){
        Intent intent = new Intent(this, ImageServiceMobile.class);
        startService(intent);
    }

    public void onClickStop(View v){
        v.setClickable(false);
        Intent intent = new Intent(this, ImageServiceMobile.class);
        stopService(intent);
    }

}