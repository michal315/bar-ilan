package com.example.rachelherzlich.imageservicemobile;

import android.util.Log;
import java.io.DataOutputStream;
import java.net.InetAddress;
import java.net.Socket;


public class TspClient {
    private Socket socket;
    private  DataOutputStream dos;

    public TspClient() {
        if (!connect()) {
            Log.e("TCP", "C: Error connection failed");
        }
    }

    /**
     * connect to server, and create DataOutputStream.
     * @return True - if it was able to connect to the server, otherwise FALSE.
     */
    private boolean connect() {
        try {
            //here you must put your computer's IP address.
            InetAddress serverAddr = InetAddress.getByName("10.0.2.2");
            // create a socket to make the connection with the server
            socket = new Socket(serverAddr, 50001);
            dos = new DataOutputStream(socket.getOutputStream());
        } catch (Exception e) {
            System.out.println("fail connect to server\n");
            Log.e("TCP", "C: Error", e);
            return false;
        }
        return true;
    }

    /**
     * send byte[] to server bt TCP client
     * @param toSend - byte[] with data
     * @return TRUE- if successful, FALSE - otherwise
     */
    public boolean sendByte( byte[] toSend) {
       try {
           dos.write(toSend);
           dos.flush();
       }catch (Exception e ){
           Log.e("TCP", "C: Error", e);
           return false;
       }
       return  true;
    }
}