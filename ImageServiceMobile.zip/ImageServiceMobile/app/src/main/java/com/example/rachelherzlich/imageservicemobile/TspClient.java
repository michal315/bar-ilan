package com.example.rachelherzlich.imageservicemobile;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Bitmap.Config;
import android.util.Log;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import java.nio.file.Files;
import java.util.Base64;
import java.util.Base64.Decoder;
import java.util.Base64.Encoder;

public class TspClient {
    private Socket socket;

    public TspClient() {
        if (!connect()) {

            //DOTO
        }
    }

    private boolean connect() {
        try {
            //here you must put your computer's IP address.
            InetAddress serverAddr = InetAddress.getByName("10.0.2.2");
            // create a socket to make the connection with the server
            socket = new Socket(serverAddr, 50001);

        } catch (Exception e) {
            System.out.println("fail connect to server\n");
            Log.e("TCP", "C: Error", e);
            return false;
        }
        return true;
    }


    public boolean sendImage(final File image) {
       try {

           DataOutputStream dos = new DataOutputStream(socket.getOutputStream());
           // send length of name
           String num = Integer.toString(image.getName().length());
           byte[] a = num.getBytes();
           System.out.println(a.length);
           dos.write(a);
           dos.flush();
           // send name
           byte[] b = image.getName().getBytes();
           dos.write(b);
           dos.flush();

           FileInputStream imageStream = new FileInputStream(image);
           Bitmap bm = BitmapFactory.decodeStream(imageStream);
           ByteArrayOutputStream stream = new ByteArrayOutputStream();
           bm.compress(Bitmap.CompressFormat.PNG, 70, stream);
           byte[] fileBytes = stream.toByteArray();
           System.out.println("file size:" + fileBytes.length);
           System.out.println("--------send:" + image.getName());
           // send length of pic
           String numofPic = Integer.toString(fileBytes.length);
           byte[] c = numofPic.getBytes();
           dos.write(c);
           dos.flush();
           //send pic
           dos.write(fileBytes);
           dos.flush();
       }catch (Exception e ){
           Log.e("TCP", "C: Error", e);
           return false;
       }
       return  true;
    }
}