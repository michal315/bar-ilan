package com.example.rachelherzlich.imageservicemobile;
import android.app.Activity;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.graphics.Color;
import android.os.Build;
import android.os.Environment;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;

import java.io.Console;
import java.io.File;
import java.util.concurrent.TimeUnit;

public class ImageModel {
    private TspClient client;
    private  Context context;
    private NotificationManagerCompat notificationManager;
    private NotificationCompat.Builder builder;
    private NotificationManager nm;
    public static final String NOTIFICATION_CHANNEL_ID = "4565";
    public static final String NOTIFICATION_CHANNEL_NAME = "channel";


    public ImageModel(Context _context){
        this.context = _context;


//Notification Channel
        CharSequence channelName = NOTIFICATION_CHANNEL_NAME;
        int importance = NotificationManager.IMPORTANCE_LOW;
        NotificationChannel notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, NOTIFICATION_CHANNEL_NAME, importance);
        notificationChannel.enableLights(true);
        notificationChannel.setLightColor(Color.RED);
        notificationChannel.enableVibration(true);
        notificationChannel.setVibrationPattern(new long[]{100, 200, 300, 400, 500, 400, 300, 200, 400});

        nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(notificationChannel);

        builder = new NotificationCompat.Builder(context, NOTIFICATION_CHANNEL_ID)
                .setDefaults(Notification.DEFAULT_ALL)
                .setSmallIcon(R.drawable.ic_launcher_background)
                .setVibrate(new long[]{100, 200, 300, 400, 500, 400, 300, 200, 400})
                .setSound(null)
                .setChannelId(NOTIFICATION_CHANNEL_ID)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(false)
                .setContentTitle("Picture Transfer")
                .setContentText("Transfer in progress");


        new Thread(new Runnable() {
            @Override public void run() {
                client = new TspClient();
            }
        }).start();
    }

    public void sendImages() {
        final File picDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
        if (picDir == null) {
            return;
        }
        Thread t = new Thread(new Runnable() {
            @Override public void run() {

                findPic(picDir);
                // At the End
                builder.setContentText("Download complete").setProgress(0, 0, false);
                nm.notify(1, builder.build());

            }
        });
        try{
            t.start();
            t.wait();


        }catch (Exception e) {

        }
    }

    public void findPic(File picDir) {

        File[] pics = picDir.listFiles();
        if (pics != null) {
            int numOfPic = pics.length;
            int progress = 1;
            for (File pic : pics) {
                if (pic.isDirectory()) {
                    findPic(pic);
                } else if(pic.isFile()){
                    while (client == null) {
                        System.out.println("connection fail");
                        try {
                            TimeUnit.SECONDS.sleep(2);
                        } catch(Exception e) {

                        }
                    }
                    String name = pic.getName();
                    if (name.substring(name.length() - 4, pic.getName().length()).equals(".jpg"))
                        client.sendImage(pic);
                        builder.setContentText("photo " + progress+"/"+numOfPic +" have been backed up").setProgress(100, progress*100/numOfPic, false);
                        nm.notify(1, builder.build());
                        progress++;
                }
            }
        }
    }
}
