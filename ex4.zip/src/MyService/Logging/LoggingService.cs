﻿using ImageService.Logging.Modal;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImageService.Logging
{
    public class LoggingService : ILoggingService
    {
        public event EventHandler<MessageRecievedEventArgs> MessageRecieved;
        private LinkedList<MessageRecievedEventArgs> logs;
        
        public LoggingService()
        {
            this.logs = new LinkedList<MessageRecievedEventArgs>();
        }
        /**
         * @arg message - message that needs to be in log file.
         * the function get message, invoke the message so the function 'onMessageReceived' in 
         * image service will be activated.
         **/
        public void Log(string message, MessageTypeEnum type)
        {
            MessageRecievedEventArgs newMessage = new MessageRecievedEventArgs();
            newMessage.Message = message;
            newMessage.Status = type;
            logs.AddLast(newMessage);
            MessageRecieved.Invoke(this, newMessage);
        }

        /**
         * the function returns a LinkList of history logs.
         **/ 
        public LinkedList<MessageRecievedEventArgs> getLogs()
        {
            return logs;
        }
    }
}
