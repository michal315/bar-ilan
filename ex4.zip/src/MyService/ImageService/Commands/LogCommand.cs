﻿using System.Collections.Generic;
using ImageService;
using ImageService.Logging;
using ImageService.Logging.Modal;


namespace MyService.ImageService.Commands
{
    class LogCommand : ICommand
    {
        ILoggingService _logging;
        public LogCommand(ILoggingService logging)
        {
            _logging = logging;
        }

        /**
         * The function get from the logging class the corrent list of the logs,
         * and returns a string according to the selected convention to TCP/
         * @param args - empty.
         **/
        public string Execute(string[] args, out bool result)
        {
            result = true;
            string allLogs = "logs#";
            LinkedList<MessageRecievedEventArgs> logs = _logging.getLogs();
            foreach (MessageRecievedEventArgs log in logs)
            {
                allLogs += log.Status;
                allLogs += "#";
                allLogs += log.Message;
                allLogs += "#";
            }
            return allLogs;
        }
    }
}
