﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ImageService.Logging.Modal;
using MyService.ImageService.Commands;
using ImageService.Logging;


namespace ImageService
{
    class ImageController : IImageController
    {
        private IImageServiceModal imageModal;                     
        private Dictionary<int, ICommand> commands;

        /**
         * @arg modal - IImageServiceModal object that we created in "ImageService".
         * Storing the Modal Of The System, and create dictionary for commands,
         * and add the commands "new file".  
         **/
        public ImageController(IImageServiceModal modal, ILoggingService logging) {
            imageModal = modal;                                     
            // set commands dictionary.
            commands = new Dictionary<int, ICommand>();
            ICommand newFile = new NewFileCommand(imageModal);
            ICommand getLogs = new LogCommand(logging);
            commands.Add(0, newFile);
            commands.Add(2, getLogs);
        }

        /**
         * @arg commandID - The key of a specific command.
         * @arg args - array that contains the args that will be used by command.
         * @arg resultSuccesful (Success or failure).
         * Finds the desired commmand using the key (commandID), and activates the execution function.
         **/
        public string ExecuteCommand(int commandID, string[] args, out bool resultSuccesful) {
               return commands[commandID].Execute(args, out resultSuccesful);
        }

        /**
         * add a new command to the map.
         * @param newCommand.
         * @param CommandId.
         **/
        public void addICommand(ICommand newCommand, int CommandID)
        {
            commands.Add(CommandID, newCommand);
        }
    }
}

      