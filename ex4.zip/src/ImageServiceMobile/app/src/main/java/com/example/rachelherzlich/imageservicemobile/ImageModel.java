package com.example.rachelherzlich.imageservicemobile;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Environment;
import android.support.v4.app.NotificationCompat;
import android.support.v4.app.NotificationManagerCompat;
import android.util.Log;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

public class ImageModel {
    private TspClient client;
    private  Context context;
    private NotificationManagerCompat notificationManager;
    private NotificationCompat.Builder builder;
    private NotificationManager nm;
    private ArrayList<String> PictureExtensionList;
    public static final String NOTIFICATION_CHANNEL_ID = "4565";
    public static final String NOTIFICATION_CHANNEL_NAME = "channel";


    public ImageModel(Context _context){
        this.context = _context;

        // creates a list of extension of picture To identify whether a file is an image.
        PictureExtensionList = new ArrayList<String>();
        PictureExtensionList.add(".jpg");
        PictureExtensionList.add(".gif");
        PictureExtensionList.add(".png");
        PictureExtensionList.add(".bmp");

        //Notification Channel
        CharSequence channelName = NOTIFICATION_CHANNEL_NAME;
        int importance = NotificationManager.IMPORTANCE_LOW;
        NotificationChannel notificationChannel = new NotificationChannel(NOTIFICATION_CHANNEL_ID, NOTIFICATION_CHANNEL_NAME, importance);
        notificationChannel.enableLights(true);
        notificationChannel.setLightColor(Color.RED);
        notificationChannel.enableVibration(true);
        notificationChannel.setVibrationPattern(new long[]{100, 200, 300, 400, 500, 400, 300, 200, 400});

        // Notification
        nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
        nm.createNotificationChannel(notificationChannel);

        // Builder
        builder = new NotificationCompat.Builder(context, NOTIFICATION_CHANNEL_ID)
                .setDefaults(Notification.DEFAULT_ALL)
                .setSmallIcon(R.drawable.ic_launcher_background)
                .setVibrate(new long[]{100, 200, 300, 400, 500, 400, 300, 200, 400})
                .setSound(null)
                .setChannelId(NOTIFICATION_CHANNEL_ID)
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(false)
                .setContentTitle("Picture Transfer")
                .setContentText("Transfer in progress");

        // connection to the server
        new Thread(new Runnable() {
            @Override public void run() {
                client = new TspClient();
            }
        }).start();
    }

    /**
     * Start backing up the images by calling a function that recursively
     * searches for all the images thar whore taken on the device.
     */
    public void start() {
        // get DCIM directory that contains all the images in the device
        final File picDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DCIM);
        if (picDir == null) {
            return;
        }
        // in new thread search for picture
        Thread t = new Thread(new Runnable() {
            @Override public void run() {
                // Search images recursively
                findPic(picDir);
                // At the End
                builder.setContentText("Download complete").setProgress(0, 0, false);
                nm.notify(1, builder.build());
            }
        });
        try{
            t.start();
        }catch (Exception e) {
            Log.e("TCP", "C: Error", e);
        }
    }

    /**
     * For each folder that contains images, go to all the files in the folder,
     * if a file is an image, move it by the TCP client to the server
     * @param picDir DCIM directory
     */
    public void findPic(File picDir) {
        File[] pics = picDir.listFiles();
        if (pics != null) {
            // param to progress bar.
            int numOfPic = pics.length;
            int progress = 1;

            for (File pic : pics) {
                if (pic.isDirectory()) {
                    findPic(pic);
                } else if(pic.isFile()){
                    while (client == null) {
                        System.out.println("connection fail");
                        try {
                            TimeUnit.SECONDS.sleep(2);
                        } catch(Exception e) {
                            Log.e("TCP", "C: Error", e);
                        }
                    }
                    // If the file has an image extension
                    String name = pic.getName();
                    if (PictureExtensionList.contains(name.substring(name.length() - 4, pic.getName().length()))) {
                        sendPic(pic);
                        // For each image that was send, we will forward the Progress Bar in 100/"number of picture"
                        builder.setContentText("photo " + progress+"/"+numOfPic +" have been backed up").setProgress(100, progress*100/numOfPic, false);
                        nm.notify(1, builder.build());
                        progress++;
                    }
                }
            }
        }
    }

    /**
     * The function prepares byte [] of: the size of the name of the image, the name of the image,
     * the size of the image, and the image.
     * And sends the byte [] with data to the server using the TCP client
     * @param image
     */
    public void sendPic(File image) {
        // send length of name
        String num = Integer.toString(image.getName().length());
        byte[] a = num.getBytes();
        client.sendByte(a);

        // send name
        byte[] b = image.getName().getBytes();
        client.sendByte(b);

        FileInputStream imageStream = null;
        try {
            imageStream = new FileInputStream(image);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

        // Convert Picture To Array Byte
        Bitmap bm = BitmapFactory.decodeStream(imageStream);
        ByteArrayOutputStream stream = new ByteArrayOutputStream();
        bm.compress(Bitmap.CompressFormat.PNG, 70, stream);
        byte[] fileBytes = stream.toByteArray();

        // send length of pic
        String numofPic = Integer.toString(fileBytes.length);
        byte[] c = numofPic.getBytes();
        client.sendByte(c);
        // send pic
        client.sendByte(fileBytes);
    }
}
